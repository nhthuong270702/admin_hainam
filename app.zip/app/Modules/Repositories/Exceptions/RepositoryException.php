<?php

namespace App\Modules\Repositories\Exceptions;

use Exception;

class RepositoryException extends Exception
{

}
