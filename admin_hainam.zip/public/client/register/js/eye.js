function myFunction() {
    var x = document.getElementById("password");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}

function myFunction1() {
    var x = document.getElementById("repassword");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}